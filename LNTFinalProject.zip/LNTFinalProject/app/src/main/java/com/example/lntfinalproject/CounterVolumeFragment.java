package com.example.lntfinalproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CounterVolumeFragment extends Fragment {

    @Override @Nullable
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_counter_volume_fragment, container, false); // mohon maap ini dari youtube :>

        TextView greeting = rootView.findViewById(R.id.greeting);
        TextView view_result = rootView.findViewById(R.id.result);

        ImageView image_sphere = rootView.findViewById(R.id.image_sphere);
        ImageView image_cuboid = rootView.findViewById(R.id.image_cuboid);
        ImageView image_pyramid = rootView.findViewById(R.id.image_pyramid);

        EditText pyramid_base = rootView.findViewById(R.id.pyramid_base);
        EditText pyramid_height = rootView.findViewById(R.id.pyramid_height);
        EditText cuboid_l = rootView.findViewById(R.id.cuboid_l);
        EditText cuboid_w = rootView.findViewById(R.id.cuboid_w);
        EditText cuboid_h = rootView.findViewById(R.id.cuboid_h);
        EditText sphere_radius = rootView.findViewById(R.id.sphere_radius);

        Button pyramid_btn = rootView.findViewById(R.id.pyramid_btn);
        Button cuboid_btn = rootView.findViewById(R.id.cuboid_btn);
        Button sphere_btn = rootView.findViewById(R.id.sphere_btn);
        Button calculate = rootView.findViewById(R.id.calculate);

        SharedPreferences SP = this.getActivity().getSharedPreferences("User_Data", Context.MODE_PRIVATE);
        greeting.setText("Welcome " + SP.getString("Name", "") + "!");

        // set initial hide = cuboid visible
        pyramid_base.setVisibility(View.VISIBLE);
        pyramid_height.setVisibility(View.VISIBLE);
        image_pyramid.setVisibility(View.VISIBLE);

        cuboid_l.setVisibility(View.INVISIBLE);
        cuboid_w.setVisibility(View.INVISIBLE);
        cuboid_h.setVisibility(View.INVISIBLE);
        image_cuboid.setVisibility(View.INVISIBLE);

        sphere_radius.setVisibility(View.INVISIBLE);
        image_sphere.setVisibility(View.INVISIBLE);

        // pyramid visible
        pyramid_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pyramid_base.setVisibility(View.VISIBLE);
                pyramid_height.setVisibility(View.VISIBLE);
                image_pyramid.setVisibility(View.VISIBLE);

                cuboid_l.setVisibility(View.INVISIBLE);
                cuboid_w.setVisibility(View.INVISIBLE);
                cuboid_h.setVisibility(View.INVISIBLE);
                image_cuboid.setVisibility(View.INVISIBLE);

                sphere_radius.setVisibility(View.INVISIBLE);
                image_sphere.setVisibility(View.INVISIBLE);
            }
        });

        // cuboid visible
        cuboid_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pyramid_base.setVisibility(View.INVISIBLE);
                pyramid_height.setVisibility(View.INVISIBLE);
                image_pyramid.setVisibility(View.INVISIBLE);

                cuboid_l.setVisibility(View.VISIBLE);
                cuboid_w.setVisibility(View.VISIBLE);
                cuboid_h.setVisibility(View.VISIBLE);
                image_cuboid.setVisibility(View.VISIBLE);

                sphere_radius.setVisibility(View.INVISIBLE);
                image_sphere.setVisibility(View.INVISIBLE);
            }
        });

        // spehere visible
        sphere_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pyramid_base.setVisibility(View.INVISIBLE);
                pyramid_height.setVisibility(View.INVISIBLE);
                image_pyramid.setVisibility(View.INVISIBLE);

                cuboid_l.setVisibility(View.INVISIBLE);
                cuboid_w.setVisibility(View.INVISIBLE);
                cuboid_h.setVisibility(View.INVISIBLE);
                image_cuboid.setVisibility(View.INVISIBLE);

                sphere_radius.setVisibility(View.VISIBLE);
                image_sphere.setVisibility(View.VISIBLE);
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if pyramid = visible
                if(pyramid_base.getVisibility() == View.VISIBLE) {
                    if(TextUtils.isEmpty(pyramid_base.getText().toString()) || TextUtils.isEmpty(pyramid_height.getText().toString())) {
                        Toast.makeText(rootView.getRootView().getContext(), "Please fill the required spaces(s)!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Double height = Double.parseDouble(pyramid_height.getText().toString());
                        Double base = Double.parseDouble(pyramid_base.getText().toString());

                        Double result = height * base * base / 3;
                        view_result.setText(result.toString());
                    }
                }
                // if cuboid = visible
                else if(cuboid_l.getVisibility() == View.VISIBLE) {
                    if(TextUtils.isEmpty(cuboid_l.getText().toString()) ||
                    TextUtils.isEmpty(cuboid_w.getText().toString()) ||
                    TextUtils.isEmpty(cuboid_h.getText().toString())) {
                        Toast.makeText(rootView.getRootView().getContext(), "Please fill the required spaces(s)!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Double length = Double.parseDouble(cuboid_l.getText().toString()),
                        width = Double.parseDouble(cuboid_w.getText().toString()),
                        height = Double.parseDouble(cuboid_h.getText().toString());

                        Double result = length * width * height;
                        view_result.setText(result.toString());
                    }
                }
                // if sphere = visible
                else if(sphere_radius.getVisibility() == View.VISIBLE) {
                    if(TextUtils.isEmpty(sphere_radius.getText().toString())) {
                        Toast.makeText(rootView.getRootView().getContext(), "Please fill the required spaces(s)!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Double radius = Double.parseDouble(sphere_radius.getText().toString());

                        Double result = 3.14 * radius * radius * radius * 4 / 3;
                        view_result.setText(Double.toString(result));
                    }
                }
            }
        });
        return rootView;
    }
}