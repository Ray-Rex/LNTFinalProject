package com.example.lntfinalproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CounterFragment extends Fragment {

    @Override @Nullable
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_counter_fragment, container, false); // mohon maap ini dari youtube :>

        TextView greeting = rootView.findViewById(R.id.greeting);
        TextView display_number = rootView.findViewById(R.id.display_number);

        Button minus_btn = rootView.findViewById(R.id.minus_btn);
        Button plus_btn = rootView.findViewById(R.id.plus_btn);
        Button reset_btn = rootView.findViewById(R.id.reset_btn);

        SharedPreferences SP = this.getActivity().getSharedPreferences("User_Data", Context.MODE_PRIVATE);
        SharedPreferences SP_number = this.getActivity().getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = SP_number.edit();

        final Integer[] number = {SP_number.getInt("Counter", 0)};
        display_number.setText(number[0].toString());

        greeting.setText("Welcome " + SP.getString("Name", "") + "!");

        minus_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number[0]--;
                editor.putInt("Counter", number[0]); editor.apply();
                display_number.setText(number[0].toString());
            }
        });

        plus_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number[0]++;
                editor.putInt("Counter", number[0]); editor.apply();
                display_number.setText(number[0].toString());
            }
        });

        reset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number[0] = 0;
                editor.putInt("Counter", number[0]); editor.apply();
                display_number.setText(number[0].toString());
            }
        });

        return rootView;
    }
}