package com.example.lntfinalproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CounterLuasFragment extends Fragment {

    @Override @Nullable
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_counter_luas_fragment, container, false); // mohon maap ini dari youtube :>

        TextView greeting = rootView.findViewById(R.id.greeting);
        TextView view_result = rootView.findViewById(R.id.result);

        ImageView image_circle = rootView.findViewById(R.id.image_circle);
        ImageView image_square = rootView.findViewById(R.id.image_square);
        ImageView image_triangle = rootView.findViewById(R.id.image_triangle);

        EditText square_side = rootView.findViewById(R.id.cuboid_l);
        EditText triangle_base = rootView.findViewById(R.id.pyramid_base);
        EditText triangle_height = rootView.findViewById(R.id.pyramid_height);
        EditText circle_radius = rootView.findViewById(R.id.sphere_radius);

        Button circle_btn = rootView.findViewById(R.id.circle_btn);
        Button triangle_btn = rootView.findViewById(R.id.triangle_btn);
        Button square_btn = rootView.findViewById(R.id.square_btn);
        Button calculate = rootView.findViewById(R.id.calculate);

        SharedPreferences SP = this.getActivity().getSharedPreferences("User_Data", Context.MODE_PRIVATE);
        greeting.setText("Welcome " + SP.getString("Name", "") + "!");

        long long result = 0;

        // set initial hide = triangle visible
        triangle_base.setVisibility(View.VISIBLE);
        triangle_height.setVisibility(View.VISIBLE);
        image_triangle.setVisibility(View.VISIBLE);

        square_side.setVisibility(View.INVISIBLE);
        image_square.setVisibility(View.INVISIBLE);

        circle_radius.setVisibility(View.INVISIBLE);
        image_circle.setVisibility(View.INVISIBLE);

        // triangle visible
        triangle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triangle_base.setVisibility(View.VISIBLE);
                triangle_height.setVisibility(View.VISIBLE);
                image_triangle.setVisibility(View.VISIBLE);

                square_side.setVisibility(View.INVISIBLE);
                image_square.setVisibility(View.INVISIBLE);

                circle_radius.setVisibility(View.INVISIBLE);
                image_circle.setVisibility(View.INVISIBLE);
            }
        });

        // square visible
        square_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triangle_base.setVisibility(View.INVISIBLE);
                triangle_height.setVisibility(View.INVISIBLE);
                image_triangle.setVisibility(View.INVISIBLE);

                square_side.setVisibility(View.VISIBLE);
                image_square.setVisibility(View.VISIBLE);

                circle_radius.setVisibility(View.INVISIBLE);
                image_circle.setVisibility(View.INVISIBLE);
            }
        });

        // circle visible
        circle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triangle_base.setVisibility(View.INVISIBLE);
                triangle_height.setVisibility(View.INVISIBLE);
                image_triangle.setVisibility(View.INVISIBLE);

                square_side.setVisibility(View.INVISIBLE);
                image_square.setVisibility(View.INVISIBLE);

                circle_radius.setVisibility(View.VISIBLE);
                image_circle.setVisibility(View.VISIBLE);
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if triangle = visible
                if(triangle_base.getVisibility() == View.VISIBLE) {
                    if(triangle_base == null || triangle_height.isEmpty()) {
                        Toast.makeText(CounterLuasFragment.this, "Please fill the required spaces(s)!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Double height = Double.parseDouble(triangle_height.getText().toString());
                        Double base = Double.parseDouble(triangle_base.getText().toString());

                        Double result = height * base / 2;
                        view_result.setText(result.toString());
                    }
                }
                // if square = visible
                else if(square_side.getVisibility() == View.VISIBLE) {
                    if(square_side.isEmpty()) {
                        Toast.makeText(CounterLuasFragment.this, "Please fill the required spaces(s)!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Double side = Double.parseDouble(square_side.getText().toString());

                        Double result = side * side;
                        view_result.setText(result.toString());
                    }
                }
                // if circle = visible
                else if(circle_radius.getVisibility() == View.VISIBLE) {
                    if(circle_radius.isEmpty()) {
                        Toast.makeText(CounterLuasFragment.this, "Please fill all required space(s)!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Double radius = Double.parseDouble(circle_radius.getText().toString());

                        Double result = 3.14 * radius * radius;
                        view_result.setText(result.toString());
                    }
                }
            }
        });
        return rootView;
    }
}