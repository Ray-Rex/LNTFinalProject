package com.example.lntfinalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText input_bimbel_id = findViewById(R.id.input_bimbel_id);
        EditText input_email = findViewById(R.id.input_email);
        EditText input_name = findViewById(R.id.input_bimbel_id);
        EditText input_password = findViewById(R.id.input_password);
        EditText input_confirm_password = findViewById(R.id.input_confirm_password);

        Button regis_button = findViewById(R.id.regis_button);
        Button login_button = findViewById(R.id.login_button);

        // kalo udah punya akun
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                finish();
            }
        });

        regis_button.setOnClickListener(new View.OnClickListener() {
            private FirebaseAuth mAuth = FirebaseAuth.getInstance();
            SharedPreferences sharedPreferences;

            @Override
            public void onClick(View v) {
                String bimbel_id = input_bimbel_id.getText().toString();
                String email = input_email.getText().toString();
                String name = input_name.getText().toString();
                String password = input_password.getText().toString();
                String confirm_password = input_confirm_password.getText().toString();

                Boolean check = true;
                if (bimbel_id.isEmpty() || email.isEmpty() || name.isEmpty() || password.isEmpty() || confirm_password.isEmpty()) {
                    check = false;
                    // kasi tau, pls isi semuanya
                    Toast.makeText(RegisterActivity.this, "Please fill all required spaces!", Toast.LENGTH_SHORT).show();
                }
                else if (!email.contains("@") || !email.endsWith(".com")) {
                    check = false;
                    // make sure format nya bener @ .com
                    Toast.makeText(RegisterActivity.this, "Email requires the character \"@\" and ends with \".com\"", Toast.LENGTH_SHORT).show();
                }
                else if (!password.equals(confirm_password)) {
                    check = false;
                    // make sure password == confirm pasword
                    Toast.makeText(RegisterActivity.this, "Confirm password has to match the initial password", Toast.LENGTH_SHORT).show();
                }

                if(check) {
                    // cek firebase ada email yang sama atau nggak
                    // save data ke firebase
                    // ke login activity
                    mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                Toast.makeText(RegisterActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                                sharedPreferences = getSharedPreferences("User_Data", MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();

                                editor.putString("Email", email);
                                editor.putString("Name", name);
                                editor.putString("Password", password);
                                editor.apply();

                                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                            }
                        }
                    });
                }
            }
        });
    }
}