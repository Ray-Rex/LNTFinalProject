package com.example.lntfinalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bot_nav = findViewById(R.id.bot_nav);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener nav_listener =
    new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment selected_fragment = null;
            switch(item.getItemId()) {
                case R.id.nav_counter: {
                    selected_fragment = new CounterFragment();
                    break;
                }
                case R.id.nav_counter_luas: {
                    selected_fragment = new CounterLuasFragment();
                    break;
                }
                case R.id.nav_counter_volume: {
                    selected_fragment = new CounterVolumeFragment();
                    break;
                }
            }
            return true;
        }
    };
}